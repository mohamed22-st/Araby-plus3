
import React from "react";

const SubscriptionPage = () => {
  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-4">
      <h1 className="text-2xl font-bold mb-4">الاشتراك الشهري</h1>
      <p className="mb-4 text-center text-gray-700">
        لدفع الاشتراك الشهري، من فضلك أرسل 50 جنيه على رقم فودافون كاش التالي:
      </p>
      <div className="text-xl font-semibold mb-4 text-red-600">01012345678</div>
      <p className="mb-6 text-gray-600">ثم اضغط على الزر التالي بعد الدفع:</p>
      <button
        onClick={() =>
          window.open("https://wa.me/201012345678?text=دفعت+الاشتراك+على+عربي+بلس", "_blank")
        }
        className="bg-green-500 text-white px-6 py-2 rounded-lg shadow hover:bg-green-600 transition"
      >
        أرسلت الدفع
      </button>
    </div>
  );
};

export default SubscriptionPage;
