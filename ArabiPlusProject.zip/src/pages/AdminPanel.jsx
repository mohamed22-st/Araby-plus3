
import React, { useState } from "react";

export default function AdminPanel() {
  const [userList, setUserList] = useState([
    { username: "student1", isSubscribed: false },
  ]);

  const toggleSubscription = (index) => {
    const updatedUsers = [...userList];
    updatedUsers[index].isSubscribed = !updatedUsers[index].isSubscribed;
    setUserList(updatedUsers);
  };

  return (
    <div className="min-h-screen bg-white p-8">
      <h1 className="text-2xl font-bold mb-6">لوحة تحكم المالك - عربي بلس</h1>

      <div className="bg-gray-100 p-6 rounded shadow mb-8">
        <h2 className="text-lg font-semibold mb-4">إضافة فيديو جديد</h2>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4">إدارة اشتراكات الطلاب</h2>
        <table className="w-full table-auto border">
          <thead>
            <tr className="bg-gray-200">
              <th className="border p-2">اسم المستخدم</th>
              <th className="border p-2">حالة الاشتراك</th>
              <th className="border p-2">إجراء</th>
            </tr>
          </thead>
          <tbody>
            {userList.map((user, index) => (
              <tr key={index} className="text-center">
                <td className="border p-2">{user.username}</td>
                <td className="border p-2">
                  {user.isSubscribed ? "مشترك" : "غير مشترك"}
                </td>
                <td className="border p-2">
                  <button
                    onClick={() => toggleSubscription(index)}
                    className="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600"
                  >
                    {user.isSubscribed ? "إلغاء" : "تفعيل"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
