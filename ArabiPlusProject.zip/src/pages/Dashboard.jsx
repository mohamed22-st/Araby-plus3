
import React from "react";

const videos = [
  {
    id: 1,
    title: "شرح درس النحو - الصف الأول الإعدادي",
    description: "مقدمة شاملة في قواعد النحو مع أمثلة تطبيقية.",
    url: "https://www.youtube.com/embed/xyz123", // استبدل بالرابط الحقيقي
  },
  {
    id: 2,
    title: "شرح البلاغة - الصف الثاني الثانوي",
    description: "درس عن الصور البيانية وأهميتها.",
    url: "https://www.youtube.com/embed/abc456", // استبدل بالرابط الحقيقي
  },
];

export default function Dashboard() {
  const user = JSON.parse(localStorage.getItem("user")); // جلب بيانات المستخدم من الlocalStorage

  if (user && !user.isSubscribed) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-lg text-red-600 font-semibold">
          يجب الاشتراك الشهري للوصول إلى المحتوى.{" "}
          <a href="/subscribe" className="text-blue-600">اشترك الآن</a>
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white py-10 px-4">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">دروس منصة عربي بلس</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {videos.map((video) => (
            <div
              key={video.id}
              className="bg-gray-50 rounded shadow p-4 border border-gray-200"
            >
              <h2 className="text-xl font-semibold mb-2">{video.title}</h2>
              <p className="text-sm text-gray-600 mb-4">{video.description}</p>
              <div className="aspect-w-16 aspect-h-9">
                <iframe
                  className="w-full h-64"
                  src={video.url}
                  title={video.title}
                  allowFullScreen
                ></iframe>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
